from dataclasses import dataclass
from typing import Optional, List
from database import get_db_session
from .repository import ListeningRepository
from hsk1.listening.schemas import *
from .schemas import *


@dataclass
class ListeningService:
    repo: ListeningRepository

    def get_listening_variants(self) -> List[ListeningSchema]:
        """Получает все доступные варианты listening заданий"""
        variants = self.repo.get_listening_variants()
        if not variants:
            return []

        return [ListeningSchema.model_validate(variant, from_attributes=True) for variant in variants]
    
    def 